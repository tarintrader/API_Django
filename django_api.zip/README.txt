API de Solicitudes de Préstamo

Este es un proyecto de Django REST Framework que proporciona una API web que recibe solicitudes de préstamo de distintos orígenes (Origen1 y Origen2) en formato JSON con estructuras diferentes, las cuales son normalizadas y almacenadas en una base de datos.

Estructuras de los JSONs

Origen1:

-nombre: Nombre de la persona solicitante.
-apellidos: Apellidos de la persona solicitante, separados por un espacio.
-fechaNacimiento: Fecha de nacimiento de la persona solicitante en formato dd/MM/yyyy.
-cantidad: Cantidad solicitada para el préstamo.

Origen2:

-nombreCompleto: Nombre y apellidos de la persona solicitante.
-fechaNacimiento: Fecha de nacimiento de la persona solicitante en formato yyyy/MM/dd.
-cantidadSolicitada: Cantidad solicitada para el préstamo.
-Normalización de las Solicitudes

La normalización de las solicitudes almacenará en el modelo 'LoanApplication' la siguiente información:

-origin: Origen de la información recibida (1 ó 2).
-full_name: Nombre y apellidos del solicitante, separados por espacios.
-name: Nombre del solicitante.
-surname: Apellidos del solicitante.
-birthdate: Fecha de nacimiento de la persona solicitante.
-amount: Cantidad solicitada para el préstamo.
-created: Fecha en la que se recibió la solicitud.

Se almacenará toda la información tanto la normalizada como la recibida de cada origen.

Instalación desde el Archivo Comprimido

1. Extrae el contenido del archivo zip en tu sistema.
2. Navega a la carpeta del proyecto:

cd ruta-a-la-carpeta-del-proyecto 

3. Instala las dependencias del proyecto usando pip:

pip install -r requirements.txt

4. Ejecuta las migraciones de la base de datos:

python manage.py migrate

5. Inicia el servidor de desarrollo:

python manage.py runserver

6. La API estará disponible en http://localhost:8000.

Contacto:

Si tienes alguna pregunta o sugerencia, contáctame en tarintrader@gmail.com.